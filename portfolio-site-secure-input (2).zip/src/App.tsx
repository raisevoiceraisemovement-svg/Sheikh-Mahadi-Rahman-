import { useEffect, useMemo, useRef, useState } from "react";
import { cn } from "./utils/cn";

type UploadItem = {
  id: string;
  name: string;
  size: string;
  type: string;
  url?: string;
};

type Entry = {
  id: string;
  title: string;
  content: string;
  tags?: string[];
  createdAt: string;
};

const PASSWORD_HASH = 759529320;
const SESSION_KEY = "sami_admin_session";

function hashPassword(input: string) {
  const prime = 131;
  const mod = 1_000_000_007;
  let hash = 0;
  for (let i = 0; i < input.length; i += 1) {
    hash = (hash * prime + input.charCodeAt(i)) % mod;
  }
  return hash;
}

function useStoredState<T>(key: string, initial: T) {
  const [state, setState] = useState<T>(() => {
    const saved = localStorage.getItem(key);
    if (saved) {
      try {
        return JSON.parse(saved) as T;
      } catch (error) {
        return initial;
      }
    }
    return initial;
  });

  useEffect(() => {
    localStorage.setItem(key, JSON.stringify(state));
  }, [key, state]);

  return [state, setState] as const;
}

function useRevealOnScroll() {
  const ref = useRef<HTMLDivElement | null>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  return { ref, visible };
}

function AdminLoginModal({
  open,
  onClose,
  onSuccess,
}: {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) {
      setPassword("");
      setError("");
    }
  }, [open]);

  if (!open) return null;

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const hash = hashPassword(password.trim());
    if (hash === PASSWORD_HASH) {
      sessionStorage.setItem(SESSION_KEY, "active");
      onSuccess();
    } else {
      setError("Authentication failed. Please try again.");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 px-4 backdrop-blur-sm">
      <div className="w-full max-w-lg rounded-3xl border border-white/10 bg-slate-950/95 p-8 shadow-2xl">
        <div className="mb-6 space-y-2">
          <p className="text-xs font-semibold uppercase tracking-[0.4em] text-rose-400">
            Secure Admin Login
          </p>
          <h2 className="text-2xl font-semibold text-white">Unlock My Input Area</h2>
          <p className="text-sm text-slate-400">
            Access is protected with session-based authentication. Your password is never exposed in the
            interface.
          </p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            placeholder="Enter secure password"
            className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-white placeholder:text-slate-500 focus:border-rose-400 focus:outline-none"
          />
          {error ? <p className="text-sm text-rose-300">{error}</p> : null}
          <div className="flex flex-col gap-3 sm:flex-row">
            <button
              type="submit"
              className="flex-1 rounded-2xl bg-rose-500 px-4 py-3 text-sm font-semibold text-white shadow-lg shadow-rose-500/40 transition hover:bg-rose-400"
            >
              Activate Admin Mode
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 rounded-2xl border border-white/10 px-4 py-3 text-sm font-semibold text-white/80 transition hover:border-white/40"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function RichTextEditor({
  value,
  onChange,
  editable,
}: {
  value: string;
  onChange: (value: string) => void;
  editable: boolean;
}) {
  const editorRef = useRef<HTMLDivElement | null>(null);

  const handleCommand = (command: string) => {
    if (!editable) return;
    document.execCommand(command, false);
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML);
    }
  };

  return (
    <div className="rounded-2xl border border-white/10 bg-black/30 p-4">
      {editable ? (
        <div className="mb-3 flex flex-wrap gap-2">
          {[
            { label: "Bold", command: "bold" },
            { label: "Italic", command: "italic" },
            { label: "Underline", command: "underline" },
            { label: "Insert Link", command: "createLink" },
          ].map((item) => (
            <button
              key={item.command}
              type="button"
              onClick={() => {
                if (item.command === "createLink") {
                  const link = window.prompt("Enter link URL");
                  if (link) {
                    document.execCommand(item.command, false, link);
                  }
                } else {
                  handleCommand(item.command);
                }
              }}
              className="rounded-full border border-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-white/80 hover:border-rose-400 hover:text-white"
            >
              {item.label}
            </button>
          ))}
        </div>
      ) : null}
      <div
        ref={editorRef}
        className={cn(
          "min-h-[140px] text-sm leading-relaxed text-slate-100",
          editable ? "outline-none" : ""
        )}
        contentEditable={editable}
        suppressContentEditableWarning
        onInput={(event) => onChange((event.target as HTMLDivElement).innerHTML)}
        dangerouslySetInnerHTML={{ __html: value }}
      />
    </div>
  );
}

function UploadManager({
  uploads,
  onUpload,
  onRemove,
  editable,
}: {
  uploads: UploadItem[];
  onUpload: (files: FileList | null) => void;
  onRemove: (id: string) => void;
  editable: boolean;
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
      <div className="mb-3 flex items-center justify-between">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-rose-300">
          Upload Manager
        </p>
        {editable ? (
          <label className="cursor-pointer rounded-full border border-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-white/80 hover:border-rose-400">
            Upload Files
            <input
              type="file"
              className="hidden"
              multiple
              onChange={(event) => onUpload(event.target.files)}
            />
          </label>
        ) : null}
      </div>
      <div className="space-y-3">
        {uploads.length === 0 ? (
          <p className="text-sm text-slate-400">No files uploaded yet.</p>
        ) : (
          uploads.map((file) => (
            <div
              key={file.id}
              className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/5 bg-black/30 px-3 py-2"
            >
              <div>
                <p className="text-sm font-medium text-white">{file.name}</p>
                <p className="text-xs text-slate-400">
                  {file.type} • {file.size}
                </p>
              </div>
              <div className="flex items-center gap-2">
                {file.url ? (
                  <a
                    href={file.url}
                    download={file.name}
                    className="rounded-full border border-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-white/70 hover:border-rose-400"
                  >
                    Download
                  </a>
                ) : null}
                {editable ? (
                  <button
                    type="button"
                    onClick={() => onRemove(file.id)}
                    className="rounded-full border border-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-white/70 hover:border-rose-400"
                  >
                    Delete
                  </button>
                ) : null}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

function EntryManager({
  label,
  entries,
  setEntries,
  editable,
}: {
  label: string;
  entries: Entry[];
  setEntries: (entries: Entry[]) => void;
  editable: boolean;
}) {
  const addEntry = () => {
    const now = new Date().toISOString();
    setEntries([
      {
        id: crypto.randomUUID(),
        title: "New Entry",
        content: "<p>Write here...</p>",
        createdAt: now,
      },
      ...entries,
    ]);
  };

  const updateEntry = (id: string, patch: Partial<Entry>) => {
    setEntries(entries.map((entry) => (entry.id === id ? { ...entry, ...patch } : entry)));
  };

  const removeEntry = (id: string) => {
    setEntries(entries.filter((entry) => entry.id !== id));
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h3 className="text-lg font-semibold text-white">{label}</h3>
        {editable ? (
          <button
            type="button"
            onClick={addEntry}
            className="rounded-full border border-white/10 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-white/70 hover:border-rose-400"
          >
            Create New Entry
          </button>
        ) : null}
      </div>
      <div className="space-y-6">
        {entries.map((entry) => (
          <div key={entry.id} className="rounded-3xl border border-white/10 bg-black/40 p-6">
            {editable ? (
              <input
                value={entry.title}
                onChange={(event) => updateEntry(entry.id, { title: event.target.value })}
                className="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-base font-semibold text-white"
              />
            ) : (
              <p className="text-xl font-semibold text-white">{entry.title}</p>
            )}
            <p className="mt-2 text-xs uppercase tracking-[0.3em] text-slate-500">
              {new Date(entry.createdAt).toLocaleDateString()}
            </p>
            <div className="mt-4">
              <RichTextEditor
                value={entry.content}
                onChange={(value) => updateEntry(entry.id, { content: value })}
                editable={editable}
              />
            </div>
            {editable ? (
              <button
                type="button"
                onClick={() => removeEntry(entry.id)}
                className="mt-4 rounded-full border border-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-white/60 hover:border-rose-400"
              >
                Delete Entry
              </button>
            ) : null}
          </div>
        ))}
        {entries.length === 0 ? (
          <p className="text-sm text-slate-400">No entries published yet.</p>
        ) : null}
      </div>
    </div>
  );
}

function EditableTitle({
  label,
  value,
  onChange,
  editable,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  editable: boolean;
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-black/50 p-4">
      <p className="text-xs font-semibold uppercase tracking-[0.3em] text-rose-300">{label}</p>
      {editable ? (
        <input
          value={value}
          onChange={(event) => onChange(event.target.value)}
          className="mt-2 w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-lg font-semibold text-white"
        />
      ) : (
        <h3 className="mt-2 text-2xl font-semibold text-white">{value}</h3>
      )}
    </div>
  );
}

function SectionWrapper({
  id,
  className,
  children,
}: {
  id: string;
  className?: string;
  children: React.ReactNode;
}) {
  const { ref, visible } = useRevealOnScroll();

  return (
    <section
      id={id}
      ref={ref}
      className={cn(
        "relative scroll-mt-20 overflow-hidden py-20",
        visible ? "animate-fade-up" : "opacity-0",
        className
      )}
    >
      {children}
    </section>
  );
}

export function App() {
  const [loginOpen, setLoginOpen] = useState(false);
  const [isAdmin, setIsAdmin] = useState(() => sessionStorage.getItem(SESSION_KEY) === "active");
  const [theme, setTheme] = useState<"dark" | "light">("dark");

  const [heroImage, setHeroImage] = useStoredState<string | null>("hero-image", null);
  const [rebelImage, setRebelImage] = useStoredState<string | null>("rebel-image", null);
  const [writerImage, setWriterImage] = useStoredState<string | null>("writer-image", null);
  const [editorImage, setEditorImage] = useStoredState<string | null>("editor-image", null);

  const [rebelTitle, setRebelTitle] = useStoredState("rebel-title", "My Manifesto");
  const [writerTitle, setWriterTitle] = useStoredState("writer-title", "Midnight Manuscripts");
  const [editorTitle, setEditorTitle] = useStoredState("editor-title", "Studio Gallery");

  const [rebelVisionEntries, setRebelVisionEntries] = useStoredState<Entry[]>("rebel-vision", [
    {
      id: crypto.randomUUID(),
      title: "Vision Entry",
      content: "<p>Share your research-driven manifesto, structured insights, and powerful analysis.</p>",
      createdAt: new Date().toISOString(),
    },
  ]);

  const [rebelResearchEntries, setRebelResearchEntries] = useStoredState<Entry[]>("rebel-research", [
    {
      id: crypto.randomUUID(),
      title: "Research Archive",
      content: "<p>Upload documents and maintain a categorized research archive for the movement.</p>",
      createdAt: new Date().toISOString(),
    },
  ]);

  const [writerEntries, setWriterEntries] = useStoredState<Entry[]>("writer-entries", [
    {
      id: crypto.randomUUID(),
      title: "Poetic Prelude",
      content: "<p>Publish poetry, stories, and intimate reflections in a cinematic reading mode.</p>",
      createdAt: new Date().toISOString(),
    },
  ]);

  const [editorEntries, setEditorEntries] = useStoredState<Entry[]>("editor-entries", [
    {
      id: crypto.randomUUID(),
      title: "Creative Project",
      content: "<p>Showcase visual edits, concepts, and project narratives.</p>",
      createdAt: new Date().toISOString(),
    },
  ]);

  const [rebelUploads, setRebelUploads] = useStoredState<UploadItem[]>("rebel-uploads", []);
  const [writerUploads, setWriterUploads] = useStoredState<UploadItem[]>("writer-uploads", []);
  const [editorUploads, setEditorUploads] = useStoredState<UploadItem[]>("editor-uploads", []);

  const [beforeImage, setBeforeImage] = useStoredState<string | null>("before-image", null);
  const [afterImage, setAfterImage] = useStoredState<string | null>("after-image", null);
  const [sliderValue, setSliderValue] = useState(55);

  const themeClasses = useMemo(
    () =>
      theme === "dark"
        ? "bg-slate-950 text-slate-100"
        : "bg-slate-100 text-slate-900",
    [theme]
  );

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
  }, [theme]);

  const handleFileUpload = (
    files: FileList | null,
    setter: (uploads: UploadItem[]) => void,
    current: UploadItem[]
  ) => {
    if (!files) return;
    const next = Array.from(files).map((file) => ({
      id: crypto.randomUUID(),
      name: file.name,
      size: `${Math.round(file.size / 1024)} KB`,
      type: file.type || "file",
      url: URL.createObjectURL(file),
    }));
    setter([...next, ...current]);
  };

  const renderImageCard = (
    image: string | null,
    onChange: (value: string) => void,
    label: string
  ) => (
    <div className="rounded-3xl border border-white/10 bg-black/40 p-4">
      <div className="flex items-center justify-between">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-rose-300">{label}</p>
        {isAdmin ? (
          <label className="cursor-pointer rounded-full border border-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-white/70 hover:border-rose-400">
            Upload
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(event) => {
                const file = event.target.files?.[0];
                if (file) {
                  onChange(URL.createObjectURL(file));
                }
              }}
            />
          </label>
        ) : null}
      </div>
      <div className="mt-4 h-56 overflow-hidden rounded-2xl border border-white/5 bg-gradient-to-br from-rose-500/20 via-black/40 to-white/10">
        {image ? (
          <img src={image} alt={label} className="h-full w-full object-cover" />
        ) : (
          <div className="flex h-full items-center justify-center text-sm text-slate-400">
            Upload image in admin mode
          </div>
        )}
      </div>
    </div>
  );

  const beforeAfterView = (
    <div className="rounded-3xl border border-white/10 bg-black/50 p-6">
      <div className="mb-4 flex items-center justify-between">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-rose-300">
          Before / After Studio
        </p>
        {isAdmin ? (
          <div className="flex flex-wrap gap-2">
            {[
              { label: "Upload Before", setter: setBeforeImage },
              { label: "Upload After", setter: setAfterImage },
            ].map((item) => (
              <label
                key={item.label}
                className="cursor-pointer rounded-full border border-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-white/70 hover:border-rose-400"
              >
                {item.label}
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(event) => {
                    const file = event.target.files?.[0];
                    if (file) {
                      item.setter(URL.createObjectURL(file));
                    }
                  }}
                />
              </label>
            ))}
          </div>
        ) : null}
      </div>
      <div className="relative h-64 overflow-hidden rounded-2xl border border-white/5">
        <div className="absolute inset-0">
          {beforeImage ? (
            <img src={beforeImage} alt="Before edit" className="h-full w-full object-cover" />
          ) : (
            <div className="flex h-full items-center justify-center bg-slate-800 text-slate-400">
              Before image
            </div>
          )}
        </div>
        <div className="absolute inset-y-0 left-0 overflow-hidden" style={{ width: `${sliderValue}%` }}>
          {afterImage ? (
            <img src={afterImage} alt="After edit" className="h-full w-full object-cover" />
          ) : (
            <div className="flex h-full items-center justify-center bg-rose-500/30 text-slate-100">
              After image
            </div>
          )}
        </div>
        <div
          className="absolute inset-y-0"
          style={{ left: `${sliderValue}%` }}
        >
          <div className="h-full w-1 bg-rose-400 shadow-lg shadow-rose-500/60" />
        </div>
      </div>
      <input
        type="range"
        min={10}
        max={90}
        value={sliderValue}
        onChange={(event) => setSliderValue(Number(event.target.value))}
        className="mt-4 w-full accent-rose-400"
      />
    </div>
  );

  return (
    <div className={cn("min-h-screen", themeClasses)}>
      <AdminLoginModal
        open={loginOpen}
        onClose={() => setLoginOpen(false)}
        onSuccess={() => {
          setIsAdmin(true);
          setLoginOpen(false);
        }}
      />

      <header className="sticky top-0 z-40 border-b border-white/10 bg-black/70 backdrop-blur-lg">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.4em] text-rose-400">Sami</p>
            <p className="text-sm font-semibold text-white">Cinematic Portfolio</p>
          </div>
          <nav className="hidden items-center gap-6 text-sm font-semibold text-white/80 md:flex">
            {[
              { label: "Home", id: "home" },
              { label: "Rebel", id: "rebel" },
              { label: "Writer", id: "writer" },
              { label: "Photo Editor", id: "editor" },
            ].map((item) => (
              <a key={item.id} href={`#${item.id}`} className="transition hover:text-rose-300">
                {item.label}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setTheme((prev) => (prev === "dark" ? "light" : "dark"))}
              className="rounded-full border border-white/10 px-3 py-2 text-xs font-semibold uppercase tracking-wide text-white/70 hover:border-rose-400"
            >
              {theme === "dark" ? "Light Mode" : "Dark Mode"}
            </button>
            {isAdmin ? (
              <button
                type="button"
                onClick={() => {
                  sessionStorage.removeItem(SESSION_KEY);
                  setIsAdmin(false);
                }}
                className="rounded-full border border-white/10 px-3 py-2 text-xs font-semibold uppercase tracking-wide text-white/70 hover:border-rose-400"
              >
                Logout
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setLoginOpen(true)}
                className="rounded-full bg-rose-500 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-white shadow-lg shadow-rose-500/40"
              >
                Admin Login
              </button>
            )}
          </div>
        </div>
      </header>

      <main>
        <SectionWrapper
          id="home"
          className="bg-gradient-to-br from-black via-slate-950 to-rose-950/40"
        >
          <div className="absolute inset-0 opacity-30" aria-hidden>
            <div className="absolute left-1/4 top-10 h-64 w-64 rounded-full bg-rose-500/40 blur-[140px]" />
            <div className="absolute bottom-0 right-0 h-72 w-72 rounded-full bg-indigo-500/30 blur-[160px]" />
          </div>
          <div className="relative mx-auto grid max-w-6xl gap-10 px-6 md:grid-cols-[1.1fr_1.4fr]">
            <div className="space-y-6">
              {renderImageCard(heroImage, setHeroImage, "Profile Photo")}
              <div className="rounded-3xl border border-white/10 bg-black/50 p-6">
                <p className="text-xs font-semibold uppercase tracking-[0.4em] text-rose-300">
                  Contact
                </p>
                <p className="mt-4 text-lg font-semibold text-white">
                  sheikhmahadirahmansami@gmail.com
                </p>
                <button className="mt-4 rounded-full bg-rose-500 px-5 py-2 text-sm font-semibold text-white shadow-lg shadow-rose-500/40">
                  Contact Now
                </button>
              </div>
            </div>
            <div className="space-y-6">
              <div className="space-y-4">
                <p className="text-xs font-semibold uppercase tracking-[0.4em] text-rose-300">
                  Cinematic Identity
                </p>
                <h1 className="text-4xl font-semibold leading-tight text-white sm:text-5xl md:text-6xl">
                  <span className="block text-white/70">Sheikh</span>
                  <span className="block animate-glow text-rose-300">
                    Mahadi Rahman Sami
                  </span>
                </h1>
                <p className="text-base text-slate-300">
                  A rebel thinker, poetic soul, and visual creator shaping multi-dimensional stories in
                  motion.
                </p>
              </div>
              <div className="grid gap-4 rounded-3xl border border-white/10 bg-black/50 p-6 sm:grid-cols-2">
                {[
                  ["Date of Birth", "25.06.2009"],
                  ["Institution", "Dhaka College"],
                  ["Blood Group", "O+"],
                  ["E-mail", "sheikhmahadirahmansami@gmail.com"],
                  ["Mobile", "01410430830"],
                ].map(([label, value]) => (
                  <div key={label} className="space-y-1">
                    <p className="text-xs uppercase tracking-[0.3em] text-slate-500">{label}</p>
                    <p className="text-sm font-semibold text-white">{value}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </SectionWrapper>

        <SectionWrapper id="rebel" className="bg-black">
          <div className="absolute inset-0 opacity-70">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_rgba(255,0,0,0.15),_transparent_50%)]" />
            <div className="absolute inset-0 bg-[linear-gradient(120deg,_rgba(255,255,255,0.05),_transparent_40%)]" />
          </div>
          <div className="relative mx-auto max-w-6xl space-y-10 px-6">
            <div className="space-y-4">
              <p className="text-xs font-semibold uppercase tracking-[0.4em] text-rose-400">
                Raise Your Voice, Raise The Movement
              </p>
              <h2 className="text-3xl font-semibold text-white sm:text-4xl">
                The Rebel Manifesto
              </h2>
              <p className="text-base text-slate-300">
                A digital manifesto forged in charcoal shadows, rebellious energy, and bold typography.
              </p>
            </div>

            <div className="grid gap-8 md:grid-cols-[1.2fr_0.8fr]">
              <div className="space-y-6">
                <EditableTitle
                  label="[My Input Area] Title"
                  value={rebelTitle}
                  onChange={setRebelTitle}
                  editable={isAdmin}
                />
                <EntryManager
                  label="My Vision"
                  entries={rebelVisionEntries}
                  setEntries={setRebelVisionEntries}
                  editable={isAdmin}
                />
                <EntryManager
                  label="My Research"
                  entries={rebelResearchEntries}
                  setEntries={setRebelResearchEntries}
                  editable={isAdmin}
                />
                <UploadManager
                  uploads={rebelUploads}
                  editable={isAdmin}
                  onUpload={(files) => handleFileUpload(files, setRebelUploads, rebelUploads)}
                  onRemove={(id) => setRebelUploads(rebelUploads.filter((file) => file.id !== id))}
                />
              </div>
              <div className="space-y-6">
                {renderImageCard(rebelImage, setRebelImage, "Section Image")}
                <div className="rounded-3xl border border-white/10 bg-black/50 p-6">
                  <p className="text-xs font-semibold uppercase tracking-[0.4em] text-rose-300">
                    Ask Any Question
                  </p>
                  <form className="mt-4 space-y-3">
                    <input
                      type="text"
                      placeholder="Your name"
                      className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-white placeholder:text-slate-500"
                    />
                    <textarea
                      placeholder="Your question"
                      className="min-h-[120px] w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-white placeholder:text-slate-500"
                    />
                    <button className="rounded-full bg-rose-500 px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-rose-500/40">
                      Send Question
                    </button>
                  </form>
                </div>
                <div className="rounded-3xl border border-white/10 bg-black/50 p-6">
                  <p className="text-xs font-semibold uppercase tracking-[0.4em] text-rose-300">
                    Contact
                  </p>
                  <p className="mt-2 text-sm font-semibold text-white">
                    raisevoiceraisemovement@gmail.com
                  </p>
                </div>
              </div>
            </div>
          </div>
        </SectionWrapper>

        <SectionWrapper
          id="writer"
          className="bg-[radial-gradient(circle_at_top,_rgba(212,175,55,0.25),_transparent_60%)]"
        >
          <div className="absolute inset-0 bg-[linear-gradient(180deg,_rgba(76,44,24,0.9),_rgba(15,10,6,0.98))]" />
          <div className="absolute inset-0 opacity-30" aria-hidden>
            <div className="absolute left-10 top-20 h-40 w-40 rounded-full bg-amber-200/30 blur-[90px]" />
            <div className="absolute right-10 bottom-20 h-52 w-52 rounded-full bg-amber-500/20 blur-[110px]" />
          </div>
          <div className="relative mx-auto max-w-6xl space-y-10 px-6">
            <div className="space-y-4">
              <p className="text-xs font-semibold uppercase tracking-[0.4em] text-amber-200">পাণ্ডুলিপি</p>
              <h2 className="text-3xl font-semibold text-amber-100 sm:text-4xl">
                The Creative Writer
              </h2>
              <p className="text-base text-amber-100/70">
                A poetic sanctuary with manuscript textures, warm glow, and intimate cinematic energy.
              </p>
            </div>
            <div className="grid gap-8 md:grid-cols-[1.2fr_0.8fr]">
              <div className="space-y-6">
                <EditableTitle
                  label="[My Input Area] Title"
                  value={writerTitle}
                  onChange={setWriterTitle}
                  editable={isAdmin}
                />
                <EntryManager
                  label="My Writings"
                  entries={writerEntries}
                  setEntries={setWriterEntries}
                  editable={isAdmin}
                />
                <UploadManager
                  uploads={writerUploads}
                  editable={isAdmin}
                  onUpload={(files) => handleFileUpload(files, setWriterUploads, writerUploads)}
                  onRemove={(id) => setWriterUploads(writerUploads.filter((file) => file.id !== id))}
                />
              </div>
              <div className="space-y-6">
                {renderImageCard(writerImage, setWriterImage, "Section Portrait")}
                <div className="rounded-3xl border border-amber-200/20 bg-amber-950/40 p-6 text-amber-100">
                  <p className="text-xs font-semibold uppercase tracking-[0.4em] text-amber-200">
                    Your Emotion
                  </p>
                  <textarea
                    placeholder="Share your feelings about the poetry"
                    className="mt-4 min-h-[140px] w-full rounded-2xl border border-amber-200/20 bg-black/30 px-4 py-2 text-amber-100 placeholder:text-amber-200/60"
                  />
                  <button className="mt-4 rounded-full bg-amber-400 px-4 py-2 text-sm font-semibold text-black shadow-lg shadow-amber-300/40">
                    Send Emotion
                  </button>
                </div>
                <button className="rounded-full border border-amber-200/30 px-4 py-2 text-sm font-semibold text-amber-100 hover:border-amber-200">
                  Email the Writer
                </button>
              </div>
            </div>
          </div>
        </SectionWrapper>

        <SectionWrapper id="editor" className="bg-slate-950">
          <div className="absolute inset-0 opacity-30" aria-hidden>
            <div className="absolute left-1/3 top-0 h-72 w-72 rounded-full bg-indigo-500/20 blur-[140px]" />
          </div>
          <div className="relative mx-auto max-w-6xl space-y-10 px-6">
            <div className="space-y-4">
              <p className="text-xs font-semibold uppercase tracking-[0.4em] text-indigo-300">
                Photo Editor
              </p>
              <h2 className="text-3xl font-semibold text-white sm:text-4xl">Modern Creative Studio</h2>
              <p className="text-base text-slate-300">
                High-contrast gallery with smooth hover reveals, modern studio polish, and visual precision.
              </p>
            </div>
            <div className="grid gap-8 md:grid-cols-[1.2fr_0.8fr]">
              <div className="space-y-6">
                <EditableTitle
                  label="[My Input Area] Title"
                  value={editorTitle}
                  onChange={setEditorTitle}
                  editable={isAdmin}
                />
                <EntryManager
                  label="My Work"
                  entries={editorEntries}
                  setEntries={setEditorEntries}
                  editable={isAdmin}
                />
                {beforeAfterView}
                <UploadManager
                  uploads={editorUploads}
                  editable={isAdmin}
                  onUpload={(files) => handleFileUpload(files, setEditorUploads, editorUploads)}
                  onRemove={(id) => setEditorUploads(editorUploads.filter((file) => file.id !== id))}
                />
              </div>
              <div className="space-y-6">
                {renderImageCard(editorImage, setEditorImage, "Section Image")}
                <div className="rounded-3xl border border-white/10 bg-black/50 p-6">
                  <p className="text-xs font-semibold uppercase tracking-[0.4em] text-indigo-300">
                    Hire Me
                  </p>
                  <button className="mt-4 rounded-full bg-indigo-500 px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-indigo-500/40">
                    Email for Projects
                  </button>
                </div>
                <div className="rounded-3xl border border-white/10 bg-black/50 p-6">
                  <p className="text-xs font-semibold uppercase tracking-[0.4em] text-indigo-300">
                    Contact
                  </p>
                  <p className="mt-2 text-sm font-semibold text-white">01410430830</p>
                </div>
              </div>
            </div>
          </div>
        </SectionWrapper>
      </main>

      <footer className="border-t border-white/10 bg-black/90 py-6 text-center text-sm text-slate-400">
        © Sheikh Mahadi Rahman Sami
      </footer>
    </div>
  );
}
